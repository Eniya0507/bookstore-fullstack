const API_BASE_URL = import.meta.env.VITE_API_URL || 'https://bookstore-6afw.onrender.com';

export default API_BASE_URL;